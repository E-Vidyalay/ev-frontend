<?php
	class Parent extends AppModel{
		
	}
?>