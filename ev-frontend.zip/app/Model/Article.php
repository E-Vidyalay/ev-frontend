<?php

class Article extends AppModel
{
}

?>