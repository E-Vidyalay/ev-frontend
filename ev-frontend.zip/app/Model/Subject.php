<?php
	class Subject extends AppModel{
		
	}
?>