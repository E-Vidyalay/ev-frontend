<?php
class Contributor extends AppModel{
	
}
 ?>
