<?php
	class Student extends AppModel{
		
	}
?>