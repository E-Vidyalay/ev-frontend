<?php
	class UserType extends AppModel{
		 
	}
?>