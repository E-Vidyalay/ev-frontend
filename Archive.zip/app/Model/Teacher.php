<?php
	class Teacher extends AppModel{
		
	}
?>